/**
 * This public class is for the BinarySearchTree data structure
 * Declare an integer variable “key” 
 * Declare a reference to the left and right child node 
 * @author Iqra Inam
 */
public class BinarySearchTree {
    int key;
    BinarySearchTree left;
    BinarySearchTree right;
/**
 * @param Create a constructor with key as the parameter 
 * this.key = key; → assigns the key value to the variable key 
 * this.left = null; → assigns the left child to null, no left child
 * this.right = null; → assigns the right child to null, no right child
 */
    public BinarySearchTree(int key) {
        this.key = key;
        this.left = null; 
        this.right = null;
    }
/**
 * Create a find method to find a node with a specified key
 * @param root - the root of the tree in which to search
 * @param searchKey - the key to search for in the tree
 * @return the node we were looking for or return null if not found
 */
    public static BinarySearchTree find(BinarySearchTree root, int searchKey) {
    	BinarySearchTree current = root;
        while (current != null && current.key != searchKey) {
            if (current.key > searchKey) {
                current = current.left;
            } else {
                current = current.right;
            }
        }
        return current;
    }
/**
 * Method to print the in-order traversal starting from the current node
 */
    public void printTree() {
        printTree(this);
    }
/**
 * Private method to display nodes in a line and arrows separating them
 * @param node - the root of the subtree 
 */
    private void printTree(BinarySearchTree node) {
        if (node == null) {
            return;
        }
        if (node.left != null) {
            printTree(node.left);
            System.out.print(" -> ");
        }
        System.out.print(node.key);
        if (node.right != null) {
            System.out.print(" -> ");
            printTree(node.right);
        }
    }
/**
 * @param Create a method with key as the parameter - the value to be inserted in the tree
 * Check if it's less than or greater than the current key - the root node
 */
    public void insert(int key) {
        if (key < this.key) {
            if (this.left == null) {
                this.left = new BinarySearchTree(key);
            } else {
                this.left.insert(key);
            }
        } else if (key > this.key) {
            if (this.right == null) {
                this.right = new BinarySearchTree(key);
            } else {
                this.right.insert(key);
            }
        }
    }
/**
 * Create a method to delete any specified key
 * @param root - the root of the subtree to search for the node to delete
 * @param key - the value of the node to be deleted
 * Checks whether the key to be deleted is less than, greater than, or equal to the key of the current root node
 * Checks whether the node to be deleted (root) has either no left child or no right child - we can replace the node with its non-null child
 * Checks whether the node to be deleted has both left and right children - we replace its value with the minimum value from its right subtree
 * Calls the delete method on the right subtree to remove the node with the minimum value
 * @return the modified root of the subtree 
 */
    public BinarySearchTree delete(BinarySearchTree root, int key) {
        if (root == null) {
            return null;
        }
        if (key < root.key) {
            root.left = delete(root.left, key);
        } else if (key > root.key) {
            root.right = delete(root.right, key);
        } else {
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }
            root.key = minValue(root.right);
            root.right = delete(root.right, root.key);
        }
        return root;
    }
/**
 * Helper method used to find the minimum value 
 * @param takes the root of the subtree as parameter
 * It iterates through the left child nodes until it reaches the leftmost node (which has the minimum value)
 * @return the minimum value found
 */
    private int minValue(BinarySearchTree root) {
        int minValue = root.key;
        while (root.left != null) {
            root = root.left;
            minValue = root.key;
        }
        return minValue;
    }
}
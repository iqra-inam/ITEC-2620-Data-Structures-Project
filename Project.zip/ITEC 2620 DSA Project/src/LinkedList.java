/**
 * This class is for the LinkedList data structure  
 * Declare integer variable “data” 
 * Declare a variable “next” of the type LinkedList to hold reference to the next node
 * @author Iqra Inam
 */
public class LinkedList {
    int data;
    LinkedList next;
/**
 * @param Create a constructor with data as the parameter 
 * this.data = data; → assigns the data value to the variable data 
 * this.next = null; → assigns the next point to null
 */
    public LinkedList(int data) {
        this.data = data;
        this.next = null;
    }
/**
 * @param Create a method insertAfter with newNode as the parameter to insert a new node in the linked list 
 * Check if the next node is null then we can assign the newNode to the next pointer else we iterate to the last node that is null and insert after it 
 */
    public void insertAfter(LinkedList newNode) {
    	if (this.next == null) {
            this.next = newNode;
        } else {
        	LinkedList current = this.next;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }
/**
 * @param Create a method delete with key as parameter because key will be the node we are deleting 
 * Three cases: head = key, head != key, and key not found
 */
    public void delete(int key) {
    	LinkedList current = this;
    	LinkedList prev = null;

        if (current != null && current.data == key) {
            this.data = this.next.data;
            this.next = this.next.next;
            return;
        }
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }
        if (current == null) {
            return;
        }
        prev.next = current.next;
    }
/**
 * Creating a method for traversing through the LinkedList 
 * Creating arrows between each node to make it easier to read
 */
    public void traverse() {
    	LinkedList current = this;
        while (current != null) {
            System.out.print(current.data);
            if (current.next != null) {
                System.out.print(" -> ");
            }
            current = current.next;
        }
        System.out.println();
    }
}
/**
 * Import array utility method
 */
import java.util.Arrays;
/**
 * This public class is for the MinHeap data structure
 * Declare an integer variable “capacity” and set it to 10 initially 
 * Declare an integer variable “size” and set it to 0  
 * Declare an integer array “items” and set it to capacity 
 * @author Iqra Inam
 */
public class MinHeap {
    private int capacity = 10;
    private int size = 0;
    private int[] items = new int[capacity];
/**
 * @param Calculate left child index with parentIndex as parameter 
 * @return the index 
 */
    private int getLeftChildIndex(int parentIndex) {
        return 2 * parentIndex + 1;
    }
/**
 * @param Calculate right child index with parentIndex as parameter 
 * @return the index 
 */
    private int getRightChildIndex(int parentIndex) {
        return 2 * parentIndex + 2;
    }
/**
 * @param Calculate parent index with childIndex as parameter 
 * @return the index 
 */
    private int getParentIndex(int childIndex) {
        return (childIndex - 1) / 2;
    }
/**
 * @param Checks if it has left child 
 * @return left child
 */
    private boolean hasLeftChild(int index) {
        return getLeftChildIndex(index) < size;
    }
/**
 * @param Checks if it has right child 
 * @return right child
 */
    private boolean hasRightChild(int index) {
        return getRightChildIndex(index) < size;
    }
/**
 * @param Checks if it has parent  
 * @return parent
 */
    private boolean hasParent(int index) {
        return getParentIndex(index) >= 0;
    }
/**
 * @param index
 * @return retrieve the value of a node's left child
 */
    private int leftChild(int index) {
        return items[getLeftChildIndex(index)];
    }
/**
 * @param index
 * @return retrieve the value of a node's right child
 */
    private int rightChild(int index) {
        return items[getRightChildIndex(index)];
    }
/**
 * @param index
 * @return retrieve the value of a node's parent
 */
    private int parent(int index) {
        return items[getParentIndex(index)];
    }
/**
 * This is used for swapping the nodes in the heap
 * Assign index1 value to temporary variable 
 * Assign the value at index2 to index1 
 * Assign the value stored in temporary variable (which was the original value at index1) to index2
 * @param index1
 * @param index2
 */
    private void swap(int index1, int index2) {
        int temp = items[index1];
        items[index1] = items[index2];
        items[index2] = temp;
    }
/**
 * Checks if size == capacity and if it does and we need to resize by doubling the array
 */
    private void extraCapacity() {
        if (size == capacity) {
            items = Arrays.copyOf(items, capacity * 2);
            capacity *= 2;
        }
    }
/**
 * @param Create a insert method with value as the parameter 
 * Used to insert a value into the heap and heapifyUp to maintain minHeap property
 * Use extraCapacity to make sure size != capacity
 */
    public void insert(int value) {
        extraCapacity();
        items[size] = value;
        size++;
        heapifyUp();
    }
/**
 * HeapifyUp method to maintain minHeap property
 */
    private void heapifyUp() {
        int index = size - 1;
        while (hasParent(index) && parent(index) > items[index]) {
            swap(getParentIndex(index), index);
            index = getParentIndex(index);
        }
    }
/**
 * Create a extractMin method 
 * Check if size is 0 
 * Store min value at index 0 and move that to the last node and size down - removing it
 * @return then we call the heapifyDown method and return the minimum value
 */
    public int extractMin() {
        if (size == 0) throw new IllegalStateException();
        int min = items[0];
        items[0] = items[size - 1];
        size--;
        heapifyDown();
        return min;
    }
/**
 * HeapifyDown method to maintain minHeap property
 */
    private void heapifyDown() {
        int index = 0;
        while (hasLeftChild(index)) {
            int smallerChildIndex = getLeftChildIndex(index);
            if (hasRightChild(index) && rightChild(index) < leftChild(index)) {
                smallerChildIndex = getRightChildIndex(index);
            }
            if (items[index] < items[smallerChildIndex]) {
                break;
            } else {
                swap(index, smallerChildIndex);
            }
            index = smallerChildIndex;
        }
    }
/**
 * @return Check if the MinHeap is empty
 * Returns true if the size is 0, indicating that the MinHeap is empty
 * Otherwise, it returns false
 */
    public boolean isEmpty() {
        return size == 0;
    }
}
/**
 * This public class is for the Queue data structure
 * This private class QueueNode can only be accessed within the Queue class
 * Declare an integer variable “data” 
 * Declare a variable “next” of the type QueueNode to hold reference to next node 
 * @author Iqra Inam
 */
public class Queue {
    private class QueueNode {
        int data;
        QueueNode next;
/**
 * @param Create a constructor with data as the parameter 
 * this.data = data; → assigns the data value to the variable data 
 * this.next = null; → assigns the next point to null
 */
        public QueueNode(int data) {
            this.data = data;
            this.next = null;
        }
    }
/**
 * Create a reference to the front and back node of the queue
 */
    private QueueNode front;
    private QueueNode back;
/** 
 * @param Create a method for enqueue with key as parameter 
 * If front is null then front is newNode and if back is not null, then the back.next node becomes newNode
 */
    public void enqueue(int key) {
    	QueueNode newNode = new QueueNode(key);
        if (front == null) {
            front = newNode; 
        }
        if (back != null) {
            back.next = newNode; 
        }
        back = newNode; 
    }
/**
 * @return Create a method for dequeue and return the dequeued value 
 * Check if front is null 
 * toReturn moves the front pointer to the next node in the queue, removing the current front node from the queue
 */
public int dequeue() {
        if (front == null) {  
            throw new IllegalStateException("Queue is empty");  
        }
        int toReturn = front.data;  
        front = front.next;  

        if (front == null) {  
            back = null;  
        }
        return toReturn; 
    }
/**
 * @return Check if the queue is empty
 * Returns true if the front is null, indicating that the queue is empty
 * Otherwise, it returns false
 */
    public boolean isEmpty() {
        return front == null;
    }
}
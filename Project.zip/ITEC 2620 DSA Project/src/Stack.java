/**
 * This public class is for the Stack data structure
 * This private class StackNode can only be accessed within the Stack class
 * Declare an integer variable “data” 
 * Declare a variable “next” of the type StackNode to hold reference to next node 
 * @author Iqra Inam
 */
public class Stack {
    private class StackNode {
        int data;
        StackNode next;
/**
 * @param We create a constructor with the integer data parameter
 * this.data = data; → assigns the data value to the variable data 
 */
        StackNode(int data) {
            this.data = data;
        }
    }
/**
 * Declare a private StackNode variable “top” which represents the top of the stack
 */
    private StackNode top;
/**
 * @param Create a method for push which takes integer key as a parameter
 * This will add a new element to the top
 */
    public void push(int key) {
        StackNode newNode = new StackNode(key);
        newNode.next = top;
        top = newNode;
    }
/**
 * @return Create a method for pop which returns an integer
 * Removes and returns the top element 
 */
    public int pop() {
        if (top == null) {
            throw new IllegalStateException("Stack is empty");
        }
        int key = top.data;
        top = top.next;
        return key;
    }
/**
 * @return Create a method for top which returns an integer
 * Returns the top element without removing it 
 */
    public int top() {
        if (top == null) {
            throw new IllegalStateException("Stack is empty");
        }
        return top.data;
    }
/**
 * @return Check if the stack is empty
 * Returns true if the top is null, indicating that the stack is empty
 * Otherwise, it returns false
 */
    public boolean isEmpty() {
        return top == null;
    }
}
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Program: Please select the data structure you want to work with: ");
        System.out.println("Enter 1 for Linked List\n"
                + "Enter 2 for Stack\n"
                + "Enter 3 for Queue\n"
                + "Enter 4 for Min Heap\n"
                + "Enter 5 for Binary Search Tree (BST)");

        int userChoice = scanner.nextInt();

        switch (userChoice) {
            case 1: // LinkedList
                System.out.println("You've selected Linked List.");
                LinkedList head = null;

                boolean exitLinkedList = false;

                while (!exitLinkedList) {
                    System.out.println("What do you want to do with the Linked List?");
                    System.out.println("1. Add Data");
                    System.out.println("2. Remove Data");
                    System.out.println("3. Display Linked List");
                    System.out.println("4. Exit");
                    System.out.print("Enter your choice (1/2/3/4): ");

                    int choice = scanner.nextInt();

                    switch (choice) {
                        case 1: // Insert Data
                            System.out.println("Enter the data to add to the Linked List (-1 to end): ");
                            int dataToAdd = scanner.nextInt();
                            while (dataToAdd != -1) {
                            	LinkedList newNode = new LinkedList(dataToAdd);
                                newNode.data = dataToAdd;
                                if (head == null) {
                                    head = newNode;
                                } else {
                                    head.insertAfter(newNode);
                                }
                                dataToAdd = scanner.nextInt();
                            }
                            break;
                        case 2: // Remove Data
                            System.out.println("Enter the data to remove from the Linked List (-1 to end): ");
                            int dataToRemove = scanner.nextInt();
                            while (dataToRemove != -1) {
                                head.delete(dataToRemove);
                                dataToRemove = scanner.nextInt();
                            }
                            break;
                        case 3: // Display Linked List
                            System.out.println("Your Linked List looks like this:");
                            if (head != null) {
                                head.traverse();
                            } else {
                                System.out.println("Empty Linked List");
                            }
                            break;
                        case 4: // Exit
                            exitLinkedList = true;
                            break;
                        default:
                            System.out.println("Invalid choice. Please select a number from 1 to 4.");
                    }
                }
                break;
            case 2: // Stack
                System.out.println("You've selected Stack.");
                Stack stack = new Stack();

                boolean exitStack = false;

                while (!exitStack) {
                    System.out.println("What do you want to do with the Stack?");
                    System.out.println("1. Push Element");
                    System.out.println("2. Pop Element");
                    System.out.println("3. Top Element");
                    System.out.println("4. Exit");
                    System.out.print("Enter your choice (1/2/3/4): ");

                    int choiceStack = scanner.nextInt();

                    switch (choiceStack) {
                        case 1: // Push 
                            System.out.println("Enter the data to push onto the Stack (-1 to end): ");
                            int dataToPush = scanner.nextInt();
                            while (dataToPush != -1) {
                                stack.push(dataToPush);
                                dataToPush = scanner.nextInt();
                            }
                            break;
                        case 2: // Pop 
                            if (!stack.isEmpty()) {
                                int poppedElement = stack.pop();
                                System.out.println("Popped element: " + poppedElement);
                            } else {
                                System.out.println("Stack is empty. Cannot pop.");
                            }
                            break;
                        case 3: // Top 
                            if (!stack.isEmpty()) {
                                int topElement = stack.top();
                                System.out.println("Top element: " + topElement);
                            } else {
                                System.out.println("Stack is empty. No top element.");
                            }
                            break;
                        case 4: // Exit
                            exitStack = true;
                            break;
                        default:
                            System.out.println("Invalid choice. Please select a number from 1 to 4.");
                    }
                }
                break;
            case 3: // Queue 
                System.out.println("You've selected Queue.");
                Queue queue = new Queue(); 
                
                boolean exitQueue = false;
                while (!exitQueue) {
                    System.out.println("What do you want to do with the Queue?");
                    System.out.println("1. Enqueue");
                    System.out.println("2. Dequeue");
                    System.out.println("3. Exit");
                    System.out.print("Enter your choice (1/2/3): ");
                    int choiceQueue = scanner.nextInt();
                    
                    switch (choiceQueue) {
                        case 1: // Enqueue
                            System.out.println("Enter the data to enqueue (-1 to end): ");
                            int dataToEnqueue = scanner.nextInt();
                            while (dataToEnqueue != -1) {
                                queue.enqueue(dataToEnqueue);
                                dataToEnqueue = scanner.nextInt();
                            }
                            break;
                        case 2: // Dequeue
                            if (!queue.isEmpty()) {
                                int dequeuedElement = queue.dequeue();
                                System.out.println("Dequeued element: " + dequeuedElement);
                            } else {
                                System.out.println("Queue is empty. Cannot dequeue.");
                            }
                            break;
                        case 3: // Exit
                            exitQueue = true;
                            break;
                        default:
                            System.out.println("Invalid choice. Please select a number from 1 to 3.");
                    }
                }
                break;
            case 4: // MinHeap
                System.out.println("You've selected Min Heap.");
                MinHeap minHeap = new MinHeap();

                boolean exitMinHeap = false;
                while (!exitMinHeap) {
                    System.out.println("What do you want to do with the Min Heap?");
                    System.out.println("1. Insert");
                    System.out.println("2. ExtractMin");
                    System.out.println("3. Exit");
                    System.out.print("Enter your choice (1/2/3): ");

                    int choiceMinHeap = scanner.nextInt();

                    switch (choiceMinHeap) {
                        case 1: // Insert
                            System.out.println("Enter the key to insert into the Min Heap (-1 to end): ");
                            int keyToInsert = scanner.nextInt();
                            while (keyToInsert != -1) {
                                minHeap.insert(keyToInsert);
                                keyToInsert = scanner.nextInt();
                            }
                            break;
                        case 2: // ExtractMin
                            if (!minHeap.isEmpty()) {
                                int minElement = minHeap.extractMin();
                                System.out.println("Min element extracted: " + minElement);
                            } else {
                                System.out.println("Min Heap is empty. Cannot extract min.");
                            }
                            break;
                        case 3: // Exit
                            exitMinHeap = true;
                            break;
                        default:
                            System.out.println("Invalid choice. Please select a number from 1 to 3.");
                    }
                }
                break;
            case 5: // Binary Search Tree
                System.out.println("You've selected Binary Search Tree (BST).");
                BinarySearchTree bst = null;

                boolean exitBST = false;
                while (!exitBST) {
                    System.out.println("What do you want to do with the Binary Search Tree?");
                    System.out.println("1. Insert Node");
                    System.out.println("2. Delete Node");
                    System.out.println("3. Find Node");
                    System.out.println("4. Inorder Traversal");
                    System.out.println("5. Exit");
                    System.out.print("Enter your choice (1/2/3/4): ");

                    int choiceBST = scanner.nextInt();

                    switch (choiceBST) {
                        case 1: // Insert 
                            System.out.println("Enter the key to insert into the BST (-1 to end): ");
                            int keyToInsert = scanner.nextInt();
                            while (keyToInsert != -1) {
                                if (bst == null) {
                                    bst = new BinarySearchTree(keyToInsert);
                                } else {
                                    bst.insert(keyToInsert);
                                }
                                keyToInsert = scanner.nextInt();
                            }
                            break;
                        case 2: // Delete 
                            if (bst == null) {
                                System.out.println("BST is empty. Cannot delete.");
                            } else {
                                System.out.println("Enter the key to delete from the BST (-1 to end): ");
                                int keyToDelete = scanner.nextInt();
                                while (keyToDelete != -1) {
                                    bst = bst.delete(bst, keyToDelete);
                                    keyToDelete = scanner.nextInt();
                                }
                            }
                            break;
                        case 3: // Find  
                        	System.out.println("Enter the key to find in the BST: ");
                            int keyToFind = scanner.nextInt();
                            BinarySearchTree foundNode = BinarySearchTree.find(bst, keyToFind);
                            if (foundNode != null) {
                                System.out.println("Node found in the BST.");
                            } else {
                                System.out.println("Node not found in the BST.");
                            }
                            break;	
                        case 4:	// Print Inorder Traversal

                        	System.out.println("Inorder Traversal of BST:");
                            if (bst != null) {
                                bst.printTree();
                                System.out.println();
                            } else {
                                System.out.println("BST is empty.");
                            }
                            break;
                        case 5: // Exit
                            exitBST = true;
                            break;
                        default:
                            System.out.println("Invalid choice. Please select a number from 1 to 4.");
                    }
                }
                break;
            default:
                System.out.println("Invalid choice. Please select a number from 1 to 5.");
        }
        scanner.close();
    }
}